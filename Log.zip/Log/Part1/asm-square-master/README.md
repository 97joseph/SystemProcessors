
## asm-square ##
Square any 1-digit number with assembly.
Built for the arm64 architectures.
