# Bu dizindeki kod sayısal tasarım dersinde verilen ödev için yazılmıştır. 

# Kodda 3 girişli bir decoder tanımlanmıştır.
