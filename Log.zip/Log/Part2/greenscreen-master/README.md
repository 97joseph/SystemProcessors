# greenscreen
This program combiness a still image with a green, blue or red screen. This can also be applied with a background or fill use case. This program will operate on PPM images. This program will also have a specific algorithm in order to generate a new image based on two input values.
